import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:sql_conn/sql_conn.dart';
import 'package:start_app/database_halper.dart';
import 'package:start_app/main.dart';
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;
  bool _isConnecting = false;
  String? _selectedUser;
  List<String> _users = [];
  Map<String, dynamic>? _connectionDetails;

  @override
  void initState() {
    super.initState();
    _loadConnectionDetails();
  }

  Future<void> _loadConnectionDetails() async {
    final details = await DatabaseHelper.instance.getConnectionDetails();
    if (details != null) {
      setState(() {
        _connectionDetails = details;
        _passwordController.text = details['password'] as String;
      });
      await _fetchUsers();
    } else {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('No saved connection details found.'),
            backgroundColor: Colors.red,
          ),
        );
        // Navigate back to ConnectionForm
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const ConnectionForm()),
        );
      }
    }
  }

  Future<void> _fetchUsers() async {
    if (_connectionDetails == null) return;

    setState(() {
      _isConnecting = true;
    });

    try {
      await SqlConn.connect(
        ip: _connectionDetails!['ip'] as String,
        port: _connectionDetails!['port'] as String,
        databaseName: _connectionDetails!['dbName'] as String,
        username: _connectionDetails!['username'] as String,
        password: _connectionDetails!['password'] as String,
      );

      // Query to fetch usernames from tbl_user in AL_BASIT database
      final result = await SqlConn.readData("SELECT username FROM tbl_user");

      // Parse the JSON string into a List<Map<String, dynamic>>
      final parsedResult = jsonDecode(result) as List<dynamic>;
      final users = parsedResult
          .map((row) => (row as Map<String, dynamic>)['username'] as String)
          .toList();

      setState(() {
        _users = users;
        _selectedUser = users.isNotEmpty ? users.first : null;
      });

      SqlConn.disconnect();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to fetch users: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
      print('Error fetching users: $e');
    } finally {
      setState(() {
        _isConnecting = false;
      });
    }
  }

  Future<void> _login() async {
    if (_formKey.currentState!.validate() && _selectedUser != null && _connectionDetails != null) {
      setState(() {
        _isConnecting = true;
      });

      try {
        await SqlConn.connect(
          ip: _connectionDetails!['ip'] as String,
          port: _connectionDetails!['port'] as String,
          databaseName: _connectionDetails!['dbName'] as String,
          username: _connectionDetails!['username'] as String,
          password: _passwordController.text,
        );

        // Clear tbl_user table
        await DatabaseHelper.instance.clearTblUser();

        if (context.mounted) {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('Success'),
              content: const Text("You're Login Successfully!"),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('OK'),
                ),
              ],
            ),
          );
        }

        SqlConn.disconnect();
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Login failed: $e'),
              backgroundColor: Colors.red,
            ),
          );
        }
        print('Error during login: $e');
      } finally {
        setState(() {
          _isConnecting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Card(
            elevation: 8,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'Login to SQL Server',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.blueAccent),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 32),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: _obscurePassword,
                    decoration: InputDecoration(
                      labelText: 'SQL Password',
                      hintText: 'Enter your password',
                      prefixIcon: const Icon(Icons.lock),
                      suffixIcon: IconButton(
                        icon: Icon(_obscurePassword ? Icons.visibility_off : Icons.visibility),
                        onPressed: () {
                          setState(() {
                            _obscurePassword = !_obscurePassword;
                          });
                        },
                      ),
                    ),
                    validator: (value) => value!.isEmpty ? 'Please enter password' : null,
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: _selectedUser,
                    decoration: const InputDecoration(
                      labelText: 'Select User',
                      prefixIcon: Icon(Icons.person),
                    ),
                    items: _users.map((user) {
                      return DropdownMenuItem<String>(
                        value: user,
                        child: Text(user),
                      );
                    }).toList(),
                    onChanged: _isConnecting
                        ? null
                        : (value) {
                            setState(() {
                              _selectedUser = value;
                            });
                          },
                    validator: (value) => value == null ? 'Please select a user' : null,
                  ),
                  const SizedBox(height: 32),
                  ElevatedButton(
                    onPressed: _isConnecting ? null : _login,
                    child: _isConnecting
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                            ),
                          )
                        : const Text('Login'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _passwordController.dispose();
    super.dispose();
  }
}
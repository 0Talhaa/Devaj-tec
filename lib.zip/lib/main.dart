import 'package:flutter/material.dart';
import 'package:sql_conn/sql_conn.dart';
import 'package:start_app/database_halper.dart'; // Ensure this path is correct
import 'package:start_app/login_screen.dart'; // Ensure this path is correct
import 'package:start_app/onboarding_screen.dart'; // Ensure this path is correct

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SQL Server Connection App',
      theme: ThemeData(
        // Define a consistent and modern primary color scheme
        primarySwatch: const MaterialColor(
          0xFF4A90E2, // A calming blue, slightly different from Dodger Blue
          <int, Color>{
            50: Color(0xFFE3F2FD),
            100: Color(0xFFBBDEFB),
            200: Color(0xFF90CAF9),
            300: Color(0xFF64B5F6),
            400: Color(0xFF42A5F5),
            500: Color(0xFF4A90E2), // Main shade
            600: Color(0xFF3F82CC),
            700: Color(0xFF3470B7),
            800: Color(0xFF295D9B),
            900: Color(0xFF1F4A80),
          },
        ),
        visualDensity: VisualDensity.adaptivePlatformDensity,
        // Set a subtle light background for the entire app scaffold
        scaffoldBackgroundColor: const Color(0xFFF0F2F5), // A very light, modern grey-blue
        fontFamily: 'Roboto', // Keep Roboto for a clean, modern look

        // AppBar theme for consistency
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF4A90E2),
          elevation: 0, // Flat app bar for modern look
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w600, // Slightly bolder title
            fontFamily: 'Roboto',
          ),
          iconTheme: IconThemeData(color: Colors.white), // White icons
        ),

        // Elevated Button theme with rounded corners and subtle shadow
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF4A90E2), // Button primary color
            foregroundColor: Colors.white, // Text color
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12), // More rounded corners
            ),
            textStyle: const TextStyle(
              fontSize: 18,
              fontFamily: 'Roboto',
              fontWeight: FontWeight.bold,
            ),
            elevation: 8, // More pronounced shadow
            shadowColor: const Color(0xFF4A90E2).withOpacity(0.4),
          ),
        ),

        // Input field decoration theme for a sleek, filled look
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none, // No explicit border
          ),
          filled: true,
          fillColor: Colors.white, // White fill for input fields
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          labelStyle: const TextStyle(
            color: Color(0xFF3470B7), // Darker blue for labels
            fontWeight: FontWeight.w500,
          ),
          hintStyle: TextStyle(
            color: const Color(0xFF4A90E2).withOpacity(0.6), // Lighter blue for hints
            fontStyle: FontStyle.italic,
          ),
          prefixIconColor: const Color(0xFF3470B7), // Icon color
          suffixIconColor: const Color(0xFF3470B7), // Icon color
        ),
      ),
      home: const OnboardingScreen(), // Starting with OnboardingScreen
    );
  }
}

class ConnectionForm extends StatefulWidget {
  const ConnectionForm({super.key});

  @override
  State<ConnectionForm> createState() => _ConnectionFormState();
}

class _ConnectionFormState extends State<ConnectionForm> with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _ipController = TextEditingController();
  final _serverNameController = TextEditingController();
  final _dbNameController = TextEditingController();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _portController = TextEditingController(text: '1433');
  bool _isConnecting = false;
  bool _obscurePassword = true;

  // Animation controllers for various UI elements
  late AnimationController _headerAnimationController;
  late Animation<double> _headerFadeAnimation;
  late Animation<Offset> _headerSlideAnimation;

  late AnimationController _cardAnimationController;
  late Animation<double> _cardScaleAnimation;
  late Animation<double> _cardFadeAnimation;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _loadSavedConnectionDetails();

    // Initialize header animations (logo and title)
    _headerAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _headerFadeAnimation = CurvedAnimation(parent: _headerAnimationController, curve: Curves.easeOut);
    _headerSlideAnimation = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(
      CurvedAnimation(parent: _headerAnimationController, curve: Curves.easeOut),
    );

    // Initialize card entrance animations
    _cardAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _cardScaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _cardAnimationController, curve: Curves.easeOutBack),
    );
    _cardFadeAnimation = CurvedAnimation(parent: _cardAnimationController, curve: Curves.easeOut);

    // Initialize pulse animation for dynamic elements (e.g., logo)
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.05).animate( // Subtle pulse
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    // Start all animations
    _headerAnimationController.forward();
    _cardAnimationController.forward();
    _pulseController.forward();
  }

  @override
  void dispose() {
    _headerAnimationController.dispose();
    _cardAnimationController.dispose();
    _pulseController.dispose();
    _ipController.dispose();
    _serverNameController.dispose();
    _dbNameController.dispose();
    _usernameController.dispose();
    _passwordController.dispose();
    _portController.dispose();
    DatabaseHelper.instance.close(); // Close database helper instance
    super.dispose();
  }

  // Loads previously saved connection details from the database
  Future<void> _loadSavedConnectionDetails() async {
    final savedDetails = await DatabaseHelper.instance.getConnectionDetails();
    if (savedDetails != null) {
      setState(() {
        _ipController.text = savedDetails['ip'] as String;
        _serverNameController.text = savedDetails['serverName'] as String;
        _dbNameController.text = savedDetails['dbName'] as String;
        _usernameController.text = savedDetails['username'] as String;
        _passwordController.text = savedDetails['password'] as String;
        _portController.text = savedDetails['port'] as String;
      });
    }
  }

  // Attempts to connect to the SQL Server
  Future<void> _connectToSqlServer() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isConnecting = true;
      });

      try {
        print('Attempting to connect to ${_ipController.text}:${_portController.text} with user ${_usernameController.text}');
        await SqlConn.connect(
          ip: _ipController.text,
          port: _portController.text,
          databaseName: _dbNameController.text,
          username: _usernameController.text,
          password: _passwordController.text,
        );

        // Save connection details on successful connection
        await DatabaseHelper.instance.saveConnectionDetails(
          ip: _ipController.text,
          serverName: _serverNameController.text,
          dbName: _dbNameController.text,
          username: _usernameController.text,
          password: _passwordController.text,
          port: _portController.text,
        );

        // Clear user table (assuming this is a setup step)
        await DatabaseHelper.instance.clearTblUser();

        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Connected successfully! Details saved locally.'),
              backgroundColor: Colors.green,
              behavior: SnackBarBehavior.floating, // Modern snackbar style
            ),
          );
          // Navigate to LoginScreen on success
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const LoginScreen()),
          );
        }
        SqlConn.disconnect(); // Disconnect after saving and navigating
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Connection failed: $e'),
              backgroundColor: Colors.red,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
        print('Error details: $e');
      } finally {
        setState(() {
          _isConnecting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Get screen width for responsive layout adjustments
    final screenWidth = MediaQuery.of(context).size.width;
    final bool isLargeScreen = screenWidth > 600;

    return Scaffold(
      // The body is wrapped in a Container with a gradient background,
      // mimicking the modern, layered look of the Pinterest inspiration.
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF8EC5FC), // Light blue start
              Color(0xFFE0C3FC), // Light purple end
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: ScaleTransition( // Apply scale animation to the card
              scale: _cardScaleAnimation,
              child: FadeTransition( // Apply fade animation to the card
                opacity: _cardFadeAnimation,
                child: Card(
                  elevation: 20, // Increased elevation for a floating effect
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20), // More rounded corners
                  ),
                  color: Colors.white.withOpacity(0.95), // Slightly transparent white card
                  child: Padding(
                    padding: const EdgeInsets.all(32.0), // Increased padding
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisSize: MainAxisSize.min, // Make column take minimum space
                      children: [
                        // Animated Header Section (Logo and Title)
                        SlideTransition(
                          position: _headerSlideAnimation,
                          child: FadeTransition(
                            opacity: _headerFadeAnimation,
                            child: AnimatedBuilder(
                              animation: _pulseAnimation,
                              builder: (context, child) {
                                return Transform.scale(
                                  scale: _pulseAnimation.value,
                                  child: isLargeScreen
                                      ? Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Image.asset(
                                              'assets/devaj_logo.png', // Ensure this asset exists
                                              width: 120,
                                              height: 120,
                                            ),
                                            const SizedBox(width: 20),
                                            const Text(
                                              'Devaj Technology', // Updated text here
                                              style: TextStyle(
                                                fontSize: 32,
                                                fontWeight: FontWeight.w900,
                                                color: Color(0xFF4A90E2),
                                                fontFamily: 'Roboto',
                                              ),
                                              textAlign: TextAlign.left,
                                            ),
                                          ],
                                        )
                                      : Column(
                                          children: [
                                            Image.asset(
                                              'assets/devaj_logo.png', // Ensure this asset exists
                                              width: screenWidth * 0.4,
                                              height: screenWidth * 0.4,
                                            ),
                                          ],
                                        ),
                                );
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 40), // More space below header

                        // Connection Form
                        Form(
                          key: _formKey,
                          child: Column(
                            children: [
                              TextFormField(
                                controller: _ipController,
                                decoration: const InputDecoration(
                                  labelText: 'IP Address',
                                  hintText: 'e.g., 192.168.1.100',
                                  prefixIcon: Icon(Icons.network_check),
                                ),
                                validator: (value) => value!.isEmpty ? 'Please enter IP address' : null,
                              ),
                              const SizedBox(height: 20),
                              TextFormField(
                                controller: _serverNameController,
                                decoration: const InputDecoration(
                                  labelText: 'Server Name',
                                  hintText: 'e.g., SERVER\\INSTANCE',
                                  prefixIcon: Icon(Icons.dns),
                                ),
                                validator: (value) => value!.isEmpty ? 'Please enter server name' : null,
                              ),
                              const SizedBox(height: 20),
                              TextFormField(
                                controller: _dbNameController,
                                decoration: const InputDecoration(
                                  labelText: 'Database Name',
                                  hintText: 'e.g., my_database',
                                  prefixIcon: Icon(Icons.storage),
                                ),
                                validator: (value) => value!.isEmpty ? 'Please enter database name' : null,
                              ),
                              const SizedBox(height: 20),
                              TextFormField(
                                controller: _usernameController,
                                decoration: const InputDecoration(
                                  labelText: 'SQL Username',
                                  hintText: 'e.g., sa',
                                  prefixIcon: Icon(Icons.person),
                                ),
                                validator: (value) => value!.isEmpty ? 'Please enter username' : null,
                              ),
                              const SizedBox(height: 20),
                              TextFormField(
                                controller: _passwordController,
                                obscureText: _obscurePassword,
                                decoration: InputDecoration(
                                  labelText: 'SQL Password',
                                  hintText: 'Enter your password',
                                  prefixIcon: const Icon(Icons.lock),
                                  suffixIcon: IconButton(
                                    icon: Icon(_obscurePassword ? Icons.visibility_off : Icons.visibility),
                                    onPressed: () {
                                      setState(() {
                                        _obscurePassword = !_obscurePassword;
                                      });
                                    },
                                  ),
                                ),
                                validator: (value) => value!.isEmpty ? 'Please enter password' : null,
                              ),
                              const SizedBox(height: 20),
                              TextFormField(
                                controller: _portController,
                                decoration: const InputDecoration(
                                  labelText: 'Port',
                                  hintText: 'e.g., 1433',
                                  prefixIcon: Icon(Icons.settings_ethernet),
                                ),
                                keyboardType: TextInputType.number,
                                validator: (value) => value!.isEmpty ? 'Please enter port' : null,
                              ),
                              const SizedBox(height: 32),
                              // Connect Button
                              ElevatedButton(
                                onPressed: _isConnecting ? null : _connectToSqlServer,
                                style: ElevatedButton.styleFrom(
                                  minimumSize: const Size(double.infinity, 55), // Full width and slightly taller
                                ),
                                child: _isConnecting
                                    ? const SizedBox(
                                        width: 24,
                                        height: 24,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 3,
                                          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                        ),
                                      )
                                    : const Text('Connect'),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
